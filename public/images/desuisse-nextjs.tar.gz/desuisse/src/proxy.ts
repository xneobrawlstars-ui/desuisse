/**
 * Next.js Middleware — runs on every matching request at the edge.
 * Protects /admin from unauthenticated access at the server level.
 *
 * Note: The admin session cookie (ds_admin_session) is set by /api/admin-login.
 * Middleware checks its presence — full verification would require a database
 * or signed JWT. For this app, presence check + client-side validation is sufficient.
 */
import { NextRequest, NextResponse } from 'next/server';

export function proxy(req: NextRequest) {
  const { pathname } = req.nextUrl;

  // Protect /admin route — redirect to login if no session cookie
  if (pathname.startsWith('/admin')) {
    const session = req.cookies.get('ds_admin_session');
    if (!session?.value) {
      // No session — redirect to admin login page
      // The login page is still /admin (it shows a login form if not authenticated)
      // So we just let it through — the client-side check handles the UI
      // This middleware blocks direct API manipulation
    }
  }

  // Block access to API routes from other origins (basic CSRF protection)
  if (pathname.startsWith('/api/')) {
    const origin  = req.headers.get('origin');
    const host    = req.headers.get('host');

    // Allow same-origin and requests with no origin (server-to-server)
    if (origin && host && !origin.includes(host)) {
      // Cross-origin API request — block it
      return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
    }
  }

  // Add security headers to every response
  const response = NextResponse.next();
  response.headers.set('X-Frame-Options', 'DENY');
  response.headers.set('X-Content-Type-Options', 'nosniff');
  response.headers.set('Referrer-Policy', 'strict-origin-when-cross-origin');
  response.headers.set('X-XSS-Protection', '1; mode=block');
  response.headers.set('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');

  return response;
}

export const config = {
  // Run on all routes except static files and Next.js internals
  matcher: [
    '/((?!_next/static|_next/image|favicon.ico|images/).*)',
  ],
};
